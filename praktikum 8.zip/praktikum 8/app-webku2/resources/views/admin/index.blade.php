<x-layout>
    <x-slot:card_title>Dashboar Admin</x-slot>
    <h3>Selamat Datang Admin {{ $username ?? ''}}!</h3>
    <p>Ini adalah halaman Admin</p>
      
</x-layout>
