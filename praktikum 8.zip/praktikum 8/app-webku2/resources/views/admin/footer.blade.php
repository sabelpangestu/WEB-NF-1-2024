<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Praktikum 9</b> PW-2
    </div>
    <strong>Copyright &copy; 2024 <a href="https://adminlte.io">Risca Marcella Jhesica</a>.</strong> All rights reserved.
  </footer>
